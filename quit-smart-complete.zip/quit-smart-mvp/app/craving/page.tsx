'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { storage } from '@/lib/storage';
import { Trigger, getAlternatives, Alternative } from '@/lib/alternativesLibrary';
import Link from 'next/link';

export default function CravingPage() {
  const router = useRouter();
  const [userTriggers, setUserTriggers] = useState<Trigger[]>([]);
  const [selectedTrigger, setSelectedTrigger] = useState<Trigger | null>(null);
  const [alternatives, setAlternatives] = useState<Alternative[]>([]);
  const [timerActive, setTimerActive] = useState(false);
  const [timeLeft, setTimeLeft] = useState(600); // 10 minutes in seconds

  useEffect(() => {
    const user = storage.getUser();
    if (!user || !user.onboardingComplete) {
      router.push('/onboarding');
      return;
    }
    setUserTriggers(user.triggers as Trigger[]);
  }, [router]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (timerActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setTimerActive(false);
    }
    return () => clearInterval(interval);
  }, [timerActive, timeLeft]);

  const handleTriggerSelect = (trigger: Trigger) => {
    setSelectedTrigger(trigger);
    setAlternatives(getAlternatives(trigger));
  };

  const startTimer = () => {
    setTimeLeft(600);
    setTimerActive(true);
  };

  const resetTimer = () => {
    setTimeLeft(600);
    setTimerActive(false);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getTriggerEmoji = (trigger: Trigger) => {
    const emojis: Record<Trigger, string> = {
      stress: '😰',
      coffee: '☕',
      after_meal: '🍽️',
      boredom: '😴',
      waiting: '⏰',
    };
    return emojis[trigger];
  };

  const getTriggerLabel = (trigger: Trigger) => {
    return trigger.replace('_', ' ').split(' ').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-100 p-4">
      <div className="max-w-md mx-auto pt-8 pb-20">
        <div className="bg-white rounded-2xl shadow-xl p-6">
          <div className="flex items-center mb-6">
            <Link href="/" className="text-indigo-600 mr-4 hover:text-indigo-700 font-medium">
              ← Back
            </Link>
            <h1 className="text-2xl font-bold text-gray-800">Craving Helper</h1>
          </div>

          {!selectedTrigger ? (
            <div>
              <div className="text-center mb-6">
                <div className="text-6xl mb-4">💭</div>
                <h2 className="text-xl font-semibold text-gray-700 mb-2">
                  What's triggering your craving?
                </h2>
                <p className="text-sm text-gray-600">
                  Select the situation you're experiencing right now
                </p>
              </div>

              <div className="space-y-3 mb-6">
                {userTriggers.map((trigger) => (
                  <button
                    key={trigger}
                    onClick={() => handleTriggerSelect(trigger)}
                    className="w-full p-5 rounded-lg border-2 border-gray-200 hover:border-purple-500 hover:bg-purple-50 transition text-left font-medium text-gray-700 flex items-center group shadow-sm hover:shadow-md"
                  >
                    <span className="text-3xl mr-4">{getTriggerEmoji(trigger)}</span>
                    <span className="flex-1 text-lg">{getTriggerLabel(trigger)}</span>
                    <span className="text-gray-400 group-hover:text-purple-500 transition">→</span>
                  </button>
                ))}
              </div>

              <div className="bg-purple-50 border-l-4 border-purple-400 p-4 rounded">
                <p className="text-sm text-purple-800">
                  💡 <strong>Remember:</strong> Cravings typically pass in 3-5 minutes. You've got this!
                </p>
              </div>
            </div>
          ) : (
            <div>
              <button
                onClick={() => {
                  setSelectedTrigger(null);
                  setAlternatives([]);
                  resetTimer();
                }}
                className="text-indigo-600 mb-4 text-sm font-medium hover:text-indigo-700 flex items-center"
              >
                ← Choose different trigger
              </button>

              <div className="text-center mb-6">
                <div className="text-5xl mb-3">{getTriggerEmoji(selectedTrigger)}</div>
                <h2 className="text-xl font-semibold text-gray-800 mb-1">
                  {getTriggerLabel(selectedTrigger)}
                </h2>
                <p className="text-sm text-gray-600">Try these alternatives instead:</p>
              </div>

              <div className="space-y-3 mb-6">
                {alternatives.map((alt, idx) => (
                  <div
                    key={idx}
                    className="bg-gradient-to-r from-purple-50 to-pink-50 p-4 rounded-lg border-2 border-purple-200 hover:border-purple-300 transition"
                  >
                    <div className="flex items-start">
                      <span className="text-2xl mr-3">✓</span>
                      <div className="flex-1">
                        <p className="font-medium text-gray-800 mb-1">{alt.action}</p>
                        <p className="text-sm text-gray-600 flex items-center">
                          <span className="mr-1">⏱️</span>
                          {alt.duration}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Timer Section */}
              <div className="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl p-6 text-center text-white shadow-lg mb-4">
                <h3 className="text-sm font-semibold mb-3 opacity-90">
                  10-Minute Delay Timer
                </h3>
                <div className="text-7xl font-bold mb-4 font-mono">
                  {formatTime(timeLeft)}
                </div>
                <p className="text-sm mb-4 opacity-90">
                  {timerActive ? 'Timer is running...' : 'Delay your next cigarette'}
                </p>
                <div className="flex gap-3">
                  {!timerActive ? (
                    <button
                      onClick={startTimer}
                      className="flex-1 bg-white text-indigo-600 py-3 rounded-lg font-semibold hover:bg-gray-100 transition shadow-md"
                    >
                      Start Timer
                    </button>
                  ) : (
                    <button
                      onClick={resetTimer}
                      className="flex-1 bg-white/20 backdrop-blur-sm text-white py-3 rounded-lg font-semibold hover:bg-white/30 transition"
                    >
                      Reset
                    </button>
                  )}
                </div>
                {timeLeft === 0 && (
                  <div className="mt-4 bg-white/20 backdrop-blur-sm rounded-lg p-3">
                    <p className="font-semibold">✅ Great job!</p>
                    <p className="text-sm opacity-90 mt-1">
                      10 minutes passed. Your craving should be weaker now.
                    </p>
                  </div>
                )}
              </div>

              {/* Motivation */}
              <div className="bg-amber-50 border-l-4 border-amber-400 p-4 rounded">
                <p className="text-sm text-amber-800">
                  <strong>💪 You're stronger than you think!</strong><br/>
                  Each craving you overcome makes the next one easier.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Back to Dashboard */}
        {selectedTrigger && (
          <Link
            href="/"
            className="block mt-4 text-center bg-white rounded-xl shadow-md p-4 text-indigo-600 font-semibold hover:bg-indigo-50 transition"
          >
            Return to Dashboard
          </Link>
        )}
      </div>
    </div>
  );
}
