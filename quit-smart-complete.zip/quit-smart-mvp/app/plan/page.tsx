'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { storage, DayPlan } from '@/lib/storage';
import { getDayNumber } from '@/lib/utils';
import Link from 'next/link';

export default function PlanPage() {
  const router = useRouter();
  const [plan, setPlan] = useState<DayPlan[]>([]);
  const [currentDay, setCurrentDay] = useState(1);
  const [baseline, setBaseline] = useState(0);

  useEffect(() => {
    const user = storage.getUser();
    const planData = storage.getPlan();

    if (!user || !user.onboardingComplete || !planData) {
      router.push('/onboarding');
      return;
    }

    setPlan(planData);
    setCurrentDay(getDayNumber(user.startDate));
    setBaseline(user.baseline);
  }, [router]);

  const getReductionPercentage = (target: number) => {
    if (baseline === 0) return 0;
    return Math.round(((baseline - target) / baseline) * 100);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-2xl mx-auto pt-8 pb-20">
        <div className="bg-white rounded-2xl shadow-xl p-6 mb-4">
          <div className="flex items-center mb-6">
            <Link href="/" className="text-indigo-600 mr-4 hover:text-indigo-700 font-medium">
              ← Back
            </Link>
            <div>
              <h1 className="text-2xl font-bold text-gray-800">Your 21-Day Plan</h1>
              <p className="text-sm text-gray-600">Complete reduction roadmap</p>
            </div>
          </div>

          {/* Summary Stats */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="bg-indigo-50 border-2 border-indigo-200 rounded-lg p-4 text-center">
              <div className="text-3xl font-bold text-indigo-600">{baseline}</div>
              <div className="text-xs text-gray-600 mt-1">Starting</div>
            </div>
            <div className="bg-purple-50 border-2 border-purple-200 rounded-lg p-4 text-center">
              <div className="text-3xl font-bold text-purple-600">{plan[20]?.target || 0}</div>
              <div className="text-xs text-gray-600 mt-1">Day 21 Goal</div>
            </div>
            <div className="bg-green-50 border-2 border-green-200 rounded-lg p-4 text-center">
              <div className="text-3xl font-bold text-green-600">
                {plan[20] ? getReductionPercentage(plan[20].target) : 0}%
              </div>
              <div className="text-xs text-gray-600 mt-1">Reduction</div>
            </div>
          </div>

          {/* Legend */}
          <div className="flex flex-wrap gap-4 mb-6 text-xs">
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-green-500 mr-2"></div>
              <span className="text-gray-600">Completed</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-indigo-500 mr-2"></div>
              <span className="text-gray-600">Today</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-gray-300 mr-2"></div>
              <span className="text-gray-600">Upcoming</span>
            </div>
          </div>

          {/* Timeline */}
          <div className="space-y-3">
            {plan.map((day) => {
              const isPast = day.day < currentDay;
              const isToday = day.day === currentDay;
              const isFuture = day.day > currentDay;

              return (
                <div
                  key={day.day}
                  className={`relative p-4 rounded-lg border-2 transition ${
                    isToday
                      ? 'border-indigo-600 bg-indigo-50 shadow-md'
                      : isPast
                      ? 'border-green-300 bg-green-50'
                      : 'border-gray-200 bg-gray-50'
                  }`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm mr-3 ${
                        isToday
                          ? 'bg-indigo-600 text-white'
                          : isPast
                          ? 'bg-green-500 text-white'
                          : 'bg-gray-300 text-gray-600'
                      }`}>
                        {day.day}
                      </div>
                      <div>
                        <span className="font-bold text-gray-800">Day {day.day}</span>
                        {isToday && (
                          <span className="ml-2 text-xs bg-indigo-600 text-white px-2 py-1 rounded-full">
                            Today
                          </span>
                        )}
                        {isPast && (
                          <span className="ml-2 text-xs bg-green-600 text-white px-2 py-1 rounded-full">
                            ✓ Done
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-3xl font-bold text-indigo-600">{day.target}</div>
                      <div className="text-xs text-gray-600">cigarettes</div>
                      <div className="text-xs text-gray-500 mt-1">
                        -{getReductionPercentage(day.target)}%
                      </div>
                    </div>
                  </div>

                  <div className="flex items-start mt-3 pt-3 border-t border-gray-200">
                    <span className="text-lg mr-2">💡</span>
                    <p className={`text-sm flex-1 ${
                      isToday ? 'text-gray-800 font-medium' : 'text-gray-700'
                    }`}>
                      {day.tip}
                    </p>
                  </div>

                  {/* Progress indicator for past days */}
                  {isPast && (
                    <div className="absolute top-0 left-0 w-1 h-full bg-green-500 rounded-l-lg"></div>
                  )}
                  {isToday && (
                    <div className="absolute top-0 left-0 w-1 h-full bg-indigo-600 rounded-l-lg"></div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Week Milestones */}
          <div className="mt-6 grid grid-cols-3 gap-3">
            <div className={`p-3 rounded-lg text-center ${
              currentDay >= 7 ? 'bg-green-50 border-2 border-green-300' : 'bg-gray-50 border-2 border-gray-200'
            }`}>
              <div className="text-2xl mb-1">{currentDay >= 7 ? '✅' : '📅'}</div>
              <div className="text-xs font-semibold text-gray-700">Week 1</div>
              <div className="text-xs text-gray-600">Days 1-7</div>
            </div>
            <div className={`p-3 rounded-lg text-center ${
              currentDay >= 14 ? 'bg-green-50 border-2 border-green-300' : 'bg-gray-50 border-2 border-gray-200'
            }`}>
              <div className="text-2xl mb-1">{currentDay >= 14 ? '✅' : '📅'}</div>
              <div className="text-xs font-semibold text-gray-700">Week 2</div>
              <div className="text-xs text-gray-600">Days 8-14</div>
            </div>
            <div className={`p-3 rounded-lg text-center ${
              currentDay >= 21 ? 'bg-green-50 border-2 border-green-300' : 'bg-gray-50 border-2 border-gray-200'
            }`}>
              <div className="text-2xl mb-1">{currentDay >= 21 ? '✅' : '📅'}</div>
              <div className="text-xs font-semibold text-gray-700">Week 3</div>
              <div className="text-xs text-gray-600">Days 15-21</div>
            </div>
          </div>
        </div>

        {/* Motivation Card */}
        <div className="bg-white rounded-xl shadow-md p-5">
          <div className="text-center">
            <div className="text-3xl mb-3">🌟</div>
            <h3 className="font-semibold text-gray-800 mb-2">Stay Consistent</h3>
            <p className="text-sm text-gray-600">
              Following this gradual plan gives you the best chance of success. Take it one day at a time!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
