'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { storage } from '@/lib/storage';
import { generatePlan } from '@/lib/planGenerator';
import { TRIGGERS, Trigger } from '@/lib/alternativesLibrary';
import { getTodayString } from '@/lib/utils';

export default function OnboardingPage() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [baseline, setBaseline] = useState(10);
  const [selectedTriggers, setSelectedTriggers] = useState<Trigger[]>([]);

  const toggleTrigger = (trigger: Trigger) => {
    if (selectedTriggers.includes(trigger)) {
      setSelectedTriggers(selectedTriggers.filter(t => t !== trigger));
    } else if (selectedTriggers.length < 3) {
      setSelectedTriggers([...selectedTriggers, trigger]);
    }
  };

  const handleComplete = () => {
    // Save user data
    storage.setUser({
      baseline,
      triggers: selectedTriggers,
      startDate: getTodayString(),
      onboardingComplete: true,
    });

    // Generate and save plan
    const plan = generatePlan(baseline);
    storage.setPlan(plan);

    // Initialize today's progress
    storage.setDailyProgress({
      date: getTodayString(),
      day: 1,
      target: plan[0].target,
      smoked: 0,
      remaining: plan[0].target,
    });

    router.push('/');
  };

  const getTriggerEmoji = (trigger: Trigger) => {
    const emojis: Record<Trigger, string> = {
      stress: '😰',
      coffee: '☕',
      after_meal: '🍽️',
      boredom: '😴',
      waiting: '⏰',
    };
    return emojis[trigger];
  };

  const getTriggerLabel = (trigger: Trigger) => {
    return trigger.replace('_', ' ').split(' ').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">QuitSmart</h1>
          <p className="text-gray-600">Your 21-day journey starts here</p>
        </div>

        {/* Step Indicator */}
        <div className="flex items-center justify-center mb-8">
          <div className={`flex items-center justify-center w-8 h-8 rounded-full font-semibold ${
            step >= 1 ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-600'
          }`}>
            1
          </div>
          <div className={`w-16 h-1 ${step >= 2 ? 'bg-indigo-600' : 'bg-gray-200'}`}></div>
          <div className={`flex items-center justify-center w-8 h-8 rounded-full font-semibold ${
            step >= 2 ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-600'
          }`}>
            2
          </div>
        </div>

        {step === 1 && (
          <div>
            <h2 className="text-xl font-semibold mb-2 text-gray-800">
              How many cigarettes do you smoke per day?
            </h2>
            <p className="text-sm text-gray-600 mb-6">
              Be honest - this helps us create your personalized plan
            </p>
            
            <div className="mb-8">
              <input
                type="range"
                min="1"
                max="60"
                value={baseline}
                onChange={(e) => setBaseline(Number(e.target.value))}
                className="w-full h-3 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                style={{
                  background: `linear-gradient(to right, #4f46e5 0%, #4f46e5 ${((baseline - 1) / 59) * 100}%, #e5e7eb ${((baseline - 1) / 59) * 100}%, #e5e7eb 100%)`
                }}
              />
              <div className="text-center mt-6">
                <div className="inline-block bg-indigo-50 rounded-2xl px-8 py-4">
                  <span className="text-6xl font-bold text-indigo-600">{baseline}</span>
                  <span className="text-gray-600 ml-2 text-lg">per day</span>
                </div>
              </div>
            </div>

            <div className="bg-blue-50 border-l-4 border-blue-400 p-4 mb-6 rounded">
              <p className="text-sm text-blue-800">
                💡 <strong>Did you know?</strong> Gradual reduction is more sustainable than quitting cold turkey.
              </p>
            </div>

            <button
              onClick={() => setStep(2)}
              className="w-full bg-indigo-600 text-white py-4 rounded-lg font-semibold text-lg hover:bg-indigo-700 transition shadow-md hover:shadow-lg"
            >
              Continue →
            </button>
          </div>
        )}

        {step === 2 && (
          <div>
            <h2 className="text-xl font-semibold mb-2 text-gray-800">
              Select your top 3 smoking triggers
            </h2>
            <p className="text-sm text-gray-600 mb-2">
              Choose the situations that make you reach for a cigarette
            </p>
            <div className="mb-6">
              <div className="inline-block bg-indigo-50 rounded-full px-4 py-1">
                <span className="text-sm font-semibold text-indigo-700">
                  Selected: {selectedTriggers.length}/3
                </span>
              </div>
            </div>

            <div className="space-y-3 mb-6">
              {TRIGGERS.map((trigger) => {
                const isSelected = selectedTriggers.includes(trigger);
                const isDisabled = !isSelected && selectedTriggers.length >= 3;
                
                return (
                  <button
                    key={trigger}
                    onClick={() => toggleTrigger(trigger)}
                    disabled={isDisabled}
                    className={`w-full p-4 rounded-lg border-2 transition text-left font-medium flex items-center ${
                      isSelected
                        ? 'border-indigo-600 bg-indigo-50 text-indigo-700 shadow-md'
                        : 'border-gray-200 hover:border-gray-300 text-gray-700 hover:bg-gray-50'
                    } disabled:opacity-40 disabled:cursor-not-allowed`}
                  >
                    <span className="text-2xl mr-3">{getTriggerEmoji(trigger)}</span>
                    <span>{getTriggerLabel(trigger)}</span>
                    {isSelected && (
                      <span className="ml-auto text-indigo-600">✓</span>
                    )}
                  </button>
                );
              })}
            </div>

            <div className="bg-amber-50 border-l-4 border-amber-400 p-4 mb-6 rounded">
              <p className="text-sm text-amber-800">
                💡 <strong>Tip:</strong> We'll give you specific alternatives for each trigger you select.
              </p>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setStep(1)}
                className="flex-1 bg-gray-200 text-gray-700 py-4 rounded-lg font-semibold hover:bg-gray-300 transition"
              >
                ← Back
              </button>
              <button
                onClick={handleComplete}
                disabled={selectedTriggers.length !== 3}
                className="flex-1 bg-indigo-600 text-white py-4 rounded-lg font-semibold hover:bg-indigo-700 transition disabled:opacity-50 disabled:cursor-not-allowed shadow-md hover:shadow-lg"
              >
                Start Journey 🚀
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
