export interface UserData {
  baseline: number;
  triggers: string[];
  startDate: string;
  onboardingComplete: boolean;
}

export interface DayPlan {
  day: number;
  target: number;
  tip: string;
}

export interface DailyProgress {
  date: string;
  day: number;
  target: number;
  smoked: number;
  remaining: number;
}

// Storage keys
const KEYS = {
  USER: 'quitSmart_user',
  PLAN: 'quitSmart_plan',
  DAILY: (date: string) => `quitSmart_daily_${date}`,
};

export const storage = {
  // User data
  getUser: (): UserData | null => {
    if (typeof window === 'undefined') return null;
    const data = localStorage.getItem(KEYS.USER);
    return data ? JSON.parse(data) : null;
  },
  
  setUser: (user: UserData) => {
    localStorage.setItem(KEYS.USER, JSON.stringify(user));
  },

  // Plan
  getPlan: (): DayPlan[] | null => {
    if (typeof window === 'undefined') return null;
    const data = localStorage.getItem(KEYS.PLAN);
    return data ? JSON.parse(data) : null;
  },
  
  setPlan: (plan: DayPlan[]) => {
    localStorage.setItem(KEYS.PLAN, JSON.stringify(plan));
  },

  // Daily progress
  getDailyProgress: (date: string): DailyProgress | null => {
    if (typeof window === 'undefined') return null;
    const data = localStorage.getItem(KEYS.DAILY(date));
    return data ? JSON.parse(data) : null;
  },
  
  setDailyProgress: (progress: DailyProgress) => {
    localStorage.setItem(KEYS.DAILY(progress.date), JSON.stringify(progress));
  },

  // Clear all
  clearAll: () => {
    Object.keys(localStorage)
      .filter(key => key.startsWith('quitSmart_'))
      .forEach(key => localStorage.removeItem(key));
  },
};
