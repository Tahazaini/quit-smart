import { DayPlan } from './storage';

// Gradual reduction curve: reduces ~70% over 21 days
// Formula: target = baseline * (0.3 + 0.7 * (21 - day) / 21)^1.5
export function generatePlan(baseline: number): DayPlan[] {
  const plan: DayPlan[] = [];
  
  for (let day = 1; day <= 21; day++) {
    // Exponential-like decay, never below 30% of baseline
    const reductionFactor = 0.3 + 0.7 * Math.pow((21 - day) / 21, 1.5);
    const target = Math.max(1, Math.round(baseline * reductionFactor));
    
    const tip = getTipForDay(day, baseline);
    
    plan.push({ day, target, tip });
  }
  
  return plan;
}

function getTipForDay(day: number, baseline: number): string {
  const tips = [
    "Start slow. Today, just track your cigarettes without judgment.",
    "Replace one smoke with a 5-minute walk.",
    "Drink water before reaching for a cigarette.",
    "Deep breathing: 4 counts in, 6 counts out.",
    "Chew gum or eat mints when cravings hit.",
    "Call a friend instead of smoking.",
    "Do 10 jumping jacks to shift your state.",
    "Delay each cigarette by 10 minutes.",
    "Avoid your usual smoking spot today.",
    "Celebrate: You're 1/3 done with your journey!",
    "Write down why you're quitting. Re-read it.",
    "Try a new route to avoid triggers.",
    "Reward yourself with something non-food.",
    "Notice: Cravings pass in 3-5 minutes.",
    "Halfway there! Keep momentum going.",
    "Replace evening smoke with herbal tea.",
    "Clean your car/home of cigarette traces.",
    "Visualize yourself as a non-smoker.",
    "Plan activities that don't involve smoking.",
    "One day left! You're almost there.",
    "Final day: Reflect on your progress. You did it!"
  ];
  
  return tips[day - 1] || "Stay strong and keep going!";
}
