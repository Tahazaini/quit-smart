export const TRIGGERS = [
  'stress',
  'coffee',
  'after_meal',
  'boredom',
  'waiting'
] as const;

export type Trigger = typeof TRIGGERS[number];

export interface Alternative {
  action: string;
  duration: string;
}

export const alternativesLibrary: Record<Trigger, Alternative[]> = {
  stress: [
    { action: "Take 10 deep breaths (4 in, 6 out)", duration: "2 min" },
    { action: "Do 20 jumping jacks or push-ups", duration: "3 min" },
    { action: "Step outside for fresh air", duration: "5 min" },
    { action: "Listen to a calming song", duration: "4 min" },
    { action: "Text a supportive friend", duration: "3 min" },
  ],
  coffee: [
    { action: "Switch to herbal tea or water", duration: "Instant" },
    { action: "Chew sugar-free gum", duration: "5 min" },
    { action: "Take a short walk with your coffee", duration: "5 min" },
    { action: "Do a quick stretch routine", duration: "3 min" },
  ],
  after_meal: [
    { action: "Brush your teeth immediately", duration: "2 min" },
    { action: "Eat a piece of fruit or mint", duration: "3 min" },
    { action: "Take a 5-minute walk", duration: "5 min" },
    { action: "Call someone to chat", duration: "5 min" },
    { action: "Do the dishes right away", duration: "5 min" },
  ],
  boredom: [
    { action: "Play a quick mobile game", duration: "5 min" },
    { action: "Read an article or book chapter", duration: "10 min" },
    { action: "Organize one small area", duration: "5 min" },
    { action: "Watch a funny video", duration: "3 min" },
    { action: "Doodle or sketch something", duration: "5 min" },
  ],
  waiting: [
    { action: "Browse social media mindfully", duration: "5 min" },
    { action: "Listen to a podcast snippet", duration: "5 min" },
    { action: "Do breathing exercises", duration: "3 min" },
    { action: "Plan your next meal or activity", duration: "3 min" },
    { action: "People-watch and observe surroundings", duration: "5 min" },
  ],
};

export function getAlternatives(trigger: Trigger): Alternative[] {
  return alternativesLibrary[trigger] || [];
}
