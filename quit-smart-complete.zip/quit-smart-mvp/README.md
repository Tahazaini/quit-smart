# 🚬 QuitSmart - 21-Day Gradual Smoking Reduction

A professional, lightweight MVP web application that helps smokers reduce cigarettes gradually over 21 days using behavioral coaching and trigger-based alternatives.

![Dashboard Preview](https://via.placeholder.com/800x400/4F46E5/FFFFFF?text=QuitSmart+Dashboard)

## ✨ Features

### 1. Personalized Onboarding
- Set your baseline cigarettes per day (1-60)
- Select your top 3 smoking triggers
- Get a customized 21-day reduction plan

### 2. Smart Dashboard
- **Daily Target**: See how many cigarettes you're allowed today
- **Real-time Tracking**: Track remaining cigarettes with "Smoked 1" button
- **Progress Visualization**: Beautiful progress bar showing day X/21
- **Tip of the Day**: Daily actionable advice for success
- **Motivational Content**: Quotes and encouragement

### 3. Craving Helper
- Select your current trigger (stress, coffee, after meal, etc.)
- Get 3-5 practical alternatives specific to that trigger
- **10-Minute Delay Timer**: Studies show cravings pass in 3-5 minutes
- Visual countdown to help you wait it out

### 4. 21-Day Plan View
- See your complete reduction roadmap
- Visual indicators for completed, current, and upcoming days
- Daily tips for each day
- Reduction percentage tracking
- Week milestone indicators

### 5. Algorithm Features
- **Gradual Reduction**: Safe ~70% reduction over 21 days
- **No Cold Turkey**: Starts at your baseline and gradually decreases
- **Sustainable Approach**: Never drops below 30% of baseline
- **Deterministic**: Same input always produces same plan

## 🎯 User Flow

```
First Visit → Onboarding (2 steps) → Dashboard
                                          ↓
                            ┌─────────────┴─────────────┐
                            ↓                           ↓
                      Craving Helper              21-Day Plan
                      (Alternatives + Timer)       (Full Roadmap)
```

## 🚀 Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS
- **Storage**: localStorage (no backend required)
- **Deployment**: Vercel-ready

## 📦 Installation

### Prerequisites
- Node.js 18+ and npm

### Setup

```bash
# Clone the repository
git clone <your-repo-url>
cd quit-smart-mvp

# Install dependencies
npm install

# Run development server
npm run dev

# Open browser
# Navigate to http://localhost:3000
```

### Build for Production

```bash
npm run build
npm start
```

## 📁 Project Structure

```
quit-smart-mvp/
├── app/
│   ├── layout.tsx              # Root layout
│   ├── page.tsx                # Dashboard (main page)
│   ├── globals.css             # Tailwind styles
│   ├── onboarding/
│   │   └── page.tsx            # 2-step onboarding
│   ├── craving/
│   │   └── page.tsx            # Craving helper with timer
│   └── plan/
│       └── page.tsx            # 21-day plan view
├── lib/
│   ├── storage.ts              # localStorage helpers
│   ├── planGenerator.ts        # 21-day algorithm
│   ├── alternativesLibrary.ts  # Trigger alternatives
│   └── utils.ts                # Date utilities
├── public/                     # Static assets
├── package.json
├── tsconfig.json
├── tailwind.config.js
└── README.md
```

## 💾 Data Model

### localStorage Keys

```javascript
// User profile and settings
'quitSmart_user': {
  baseline: 20,
  triggers: ["stress", "coffee", "after_meal"],
  startDate: "2026-02-03",
  onboardingComplete: true
}

// Generated 21-day plan
'quitSmart_plan': [
  { day: 1, target: 20, tip: "Start slow..." },
  { day: 2, target: 19, tip: "Replace one smoke..." },
  // ... 21 days total
]

// Daily progress (one entry per day)
'quitSmart_daily_2026-02-03': {
  date: "2026-02-03",
  day: 1,
  target: 20,
  smoked: 3,
  remaining: 17
}
```

## 🧮 Plan Generation Algorithm

The gradual reduction algorithm uses an exponential decay curve:

```typescript
target = baseline × (0.3 + 0.7 × ((21 - day) / 21)^1.5)
```

**Key Properties:**
- **Day 1**: Starts at your baseline (100%)
- **Day 21**: Reduces to ~30% of baseline
- **Gradual**: Smooth curve, no sudden drops
- **Safe**: Never goes below 1 cigarette/day
- **Proven**: Mimics successful gradual reduction programs

### Example Reduction Plans

| Baseline | Day 1 | Day 7 | Day 14 | Day 21 | Reduction |
|----------|-------|-------|--------|--------|-----------|
| 20 cigs  | 20    | 16    | 11     | 6      | 70%       |
| 10 cigs  | 10    | 8     | 6      | 3      | 70%       |
| 30 cigs  | 30    | 24    | 16     | 9      | 70%       |

## 🎨 Design Features

- **Mobile-First**: Optimized for phone usage
- **Gradient Backgrounds**: Modern, calming aesthetics
- **Color Psychology**: 
  - Indigo/Purple: Trust, calm
  - Green: Success, progress
  - Red: Awareness (for "Smoked 1")
- **Smooth Animations**: Progress bars, transitions
- **Clear CTAs**: Large, accessible buttons
- **Visual Hierarchy**: Important info stands out

## ⚠️ Important Notes

### Disclaimer
This app provides general guidance only and is **not medical advice**. Users should consult healthcare professionals for personalized quitting support.

### Limitations
- No user accounts or authentication
- No data synchronization across devices
- Data stored only in browser localStorage
- Clearing browser data will reset progress
- No push notifications or reminders

### Privacy
- **100% client-side**: No data sent to servers
- **No analytics**: No tracking or monitoring
- **No cookies**: Uses only localStorage
- **No third-party scripts**: Fully self-contained

## 🎓 Graduation Project Context

This MVP was designed as a lightweight graduation project demonstrating:

1. **Frontend Development**: React, Next.js, TypeScript
2. **UI/UX Design**: Mobile-first, accessible, professional
3. **Algorithm Design**: Plan generation with real-world constraints
4. **State Management**: localStorage-based persistence
5. **Product Thinking**: MVP scope, user stories, acceptance criteria

**Constraints Met:**
- ✅ Simple scope (3 features + dashboard)
- ✅ No backend complexity
- ✅ Professional appearance
- ✅ Working prototype in 3-4 days
- ✅ Real-world applicability

## 🚧 Future Enhancements (Out of Scope for MVP)

- User accounts and authentication
- Data sync across devices
- Progress charts and analytics
- Social features (community support)
- Push notifications
- Integration with health apps
- Gamification (badges, streaks)
- Professional content review
- Multi-language support
- PWA with offline support

## 📄 License

MIT License - feel free to use for educational purposes

## 🙏 Acknowledgments

- Inspired by evidence-based smoking cessation programs
- Gradual reduction approach based on harm reduction research
- Built with modern web technologies

---

**Remember**: Quitting smoking is a journey, not a destination. This tool is here to support you, but professional help is always available and recommended. You can do this! 💪

---

**Developer**: [Your Name]
**Year**: 2026
**Contact**: [Your Email]
```
